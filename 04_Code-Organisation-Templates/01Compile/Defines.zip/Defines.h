#define STANDARD_TEMPLATE_LIBRARY namespace std

#define  DONT_COMPILE_THIS

#include<iostream>

using namespace std;