
#ifndef CPP_ADVANCED_DEFINES_H
#define CPP_ADVANCED_DEFINES_H

#define DONT_COMPILE_THIS
#define STANDARD_TEMPLATE_LIBRARY namespace std;

#include <string>
#include <iostream>

#endif //CPP_ADVANCED_DEFINES_H